/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csci3830.usermanagementproject2.jsf;

import com.csci3830.usermanagementproject2.jpa.entities.Userlogin;

/**
 *
 * @author Christian Kolb
 */
class entityManager {

    static Userlogin find(Class<Userlogin> aClass, int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
