/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csci3830.usermanagementproject2;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.Serializable;

/**
 *
 * @author Christian Kolb
 */
@Named("SessionBean")
@SessionScoped
public class SessionBean implements Serializable {
    private String username;

    public String getUsername() {
        return username;
    }

    public void checkLoginFromUserPage() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);  
        if(session == null){
        }
        else{  
            boolean isLoggedIn = (boolean) session.getAttribute("isLoggedIn");
            if(isLoggedIn == false){
                HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
                response.setContentType("text/html");
                response.getWriter().write("<script>setTimeout(function() { window.location='LoginPage.xhtml'; }, 1000);</script>");
                context.responseComplete();
            }  
        }  
    }
    public void checkLoginFromLoginPage() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false); 
        if(session == null){
        }
        else{ 
            if(session.getAttribute("isLoggedIn") == null){
                session.setAttribute("isLoggedIn", false);
            }else{
                boolean isLoggedIn = (boolean) session.getAttribute("isLoggedIn");
                if(isLoggedIn == true){
                    HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
                    response.setContentType("text/html");
                    response.getWriter().write("<script>setTimeout(function() { window.location='UserPage.xhtml'; }, 1000);</script>");
                    context.responseComplete();
                }
            } 
        }  
    }
    
    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        session.setAttribute("isLoggedIn", false);
        return "LoginPage.xhtml?faces-redirect=true";
    }
}