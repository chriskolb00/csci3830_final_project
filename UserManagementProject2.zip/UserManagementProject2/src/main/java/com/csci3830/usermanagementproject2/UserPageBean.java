/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csci3830.usermanagementproject2;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.ComponentSystemEvent;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
/**
 *
 * @author Christian Kolb
 */
@Named("UserPageBean")
@RequestScoped
public class UserPageBean {
    @PostConstruct
    public void init() {
        System.out.println("UserPageBean initialized");
    }
    public String getUsername() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        String username = (String) session.getAttribute("username");
        System.out.println("Retrieved Username: " + username);
        return username;
    }
    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        session.setAttribute("isLoggedIn", false);
        if (session != null) {
            session.invalidate();
        }
        return "LoginPage.xhtml?faces-redirect=true"; // Redirect to login page after logout
    }
}
