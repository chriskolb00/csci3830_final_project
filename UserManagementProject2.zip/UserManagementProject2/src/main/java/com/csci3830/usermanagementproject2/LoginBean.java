/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csci3830.usermanagementproject2;
import com.csci3830.usermanagementproject2.jpa.session.UserloginFacade;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 *
 * @author Christian Kolb
 */
@Named
@RequestScoped
public class LoginBean {
    private String username;
    private String password;

    @EJB
    private UserloginFacade userloginFacade;
    
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String login() throws IOException {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
        
        String sessionId = session.getId();
        
        response.setHeader("Session-ID", sessionId);
        if(username.equals("admin") && password.equals("admin")){
            return "admin.xhtml";
        }
        if (userloginFacade.validateLogin(username, password)) {
            context.getExternalContext().getFlash().setKeepMessages(true);
            session.setAttribute("username", username);
            session.setAttribute("isLoggedIn", true);
            session.setAttribute("userId", userloginFacade.getIdFromUsername(username));
            return "UserPage.xhtml?faces-redirect=true"; // Redirect to home page
        } else {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login failed, try again or create an account!", "Invalid username or password"));
            context.getExternalContext().getFlash().setKeepMessages(true); 
            return "LoginPage.xhtml?faces-redirect=true"; 
        }
    }
}
