/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csci3830.usermanagementproject2.jpa.session;

import com.csci3830.usermanagementproject2.jpa.entities.Userlogin;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PersistenceContext;

/**
 *
 * @author Christian Kolb
 */
@Stateless
public class UserloginFacade extends AbstractFacade<Userlogin> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UserloginFacade() {
        super(Userlogin.class);
    }
    public Userlogin findUserByUsername(String username) {
        try {
            return em.createNamedQuery("Userlogin.findByUsername", Userlogin.class)
                     .setParameter("username", username)
                     .getSingleResult();
        } catch (NoResultException nre) {
            return null;
        }
    }
    public boolean validateLogin(String username, String password) {
        Userlogin user = findUserByUsername(username);
        
        if (user != null && user.getPassword().equals(password)) {
            return true;  // Password matches
        }
        return false;
    } 
    public int getIdFromUsername(String username) {
        Userlogin user = findUserByUsername(username);
        
        if (user != null && user.getId()!= null) {
             return user.getId();
        } 
        return 0;
    } 
}
